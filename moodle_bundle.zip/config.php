<?php
unset($CFG); $CFG = new stdClass();
$CFG->dbtype='mysqli'; $CFG->dblibrary='native';
$CFG->dbhost='db'; $CFG->dbname='moodle';
$CFG->dbuser='moodle'; $CFG->dbpass='moodlepass';
$CFG->prefix='mdl_';
$CFG->dboptions=['dbpersist'=>0,'dbport'=>3306,'dbsocket'=>false,'dbcollation'=>'utf8mb4_unicode_ci'];
$CFG->wwwroot='http://localhost:8080';  // якщо заходять з іншого ПК — постав http://<твій-IP>:8080
$CFG->dataroot='/var/www/moodledata'; $CFG->directorypermissions=0777; $CFG->admin='admin';
require_once(__DIR__.'/lib/setup.php');
